import Vue from 'vue'
import VuetifyDaterangePicker from "vuetify-daterange-picker"
import "vuetify-daterange-picker/dist/vuetify-daterange-picker.css"

Vue.use(VuetifyDaterangePicker)
