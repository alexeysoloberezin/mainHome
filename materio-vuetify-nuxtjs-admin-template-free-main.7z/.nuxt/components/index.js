export { default as AppBarUserMenu } from '../..\\components\\AppBarUserMenu.vue'
export { default as ThemeSwitcher } from '../..\\components\\ThemeSwitcher.vue'
export { default as UpgradeToPro } from '../..\\components\\UpgradeToPro.vue'
export { default as AccountSettingsAccount } from '../..\\components\\account-settings\\AccountSettingsAccount.vue'
export { default as AccountSettingsInfo } from '../..\\components\\account-settings\\AccountSettingsInfo.vue'
export { default as AccountSettingsSecurity } from '../..\\components\\account-settings\\AccountSettingsSecurity.vue'
export { default as CardsCardBasic } from '../..\\components\\cards\\CardBasic.vue'
export { default as CardsCardNavigation } from '../..\\components\\cards\\CardNavigation.vue'
export { default as CardsCardSolid } from '../..\\components\\cards\\CardSolid.vue'
export { default as Contacts } from '../..\\components\\contacts\\Contacts.vue'
export { default as DashboardCardDepositAndWithdraw } from '../..\\components\\dashboard\\DashboardCardDepositAndWithdraw.vue'
export { default as DashboardCardSalesByCountries } from '../..\\components\\dashboard\\DashboardCardSalesByCountries.vue'
export { default as DashboardCardTotalEarning } from '../..\\components\\dashboard\\DashboardCardTotalEarning.vue'
export { default as DashboardCongratulationJohn } from '../..\\components\\dashboard\\DashboardCongratulationJohn.vue'
export { default as DashboardDatatable } from '../..\\components\\dashboard\\DashboardDatatable.vue'
export { default as DashboardStatisticsCard } from '../..\\components\\dashboard\\DashboardStatisticsCard.vue'
export { default as DashboardWeeklyOverview } from '../..\\components\\dashboard\\DashboardWeeklyOverview.vue'
export { default as DashboardDashIndex } from '../..\\components\\dashboard\\DashIndex.vue'
export { default as DashboardDatatableData } from '../..\\components\\dashboard\\datatable-data.js'
export { default as Price } from '../..\\components\\price\\Price.vue'
export { default as IconBed } from '../..\\components\\icon\\Bed.vue'
export { default as IconBedIcon } from '../..\\components\\icon\\BedIcon.vue'
export { default as IconBeth } from '../..\\components\\icon\\Beth.vue'
export { default as IconCross } from '../..\\components\\icon\\Cross.vue'
export { default as IconGuest } from '../..\\components\\icon\\Guest.vue'
export { default as IconInstagram } from '../..\\components\\icon\\Instagram.vue'
export { default as IconLink } from '../..\\components\\icon\\Link.vue'
export { default as IconRooms } from '../..\\components\\icon\\Rooms.vue'
export { default as IconShowerIcon } from '../..\\components\\icon\\ShowerIcon.vue'
export { default as IconTelegramIcon } from '../..\\components\\icon\\TelegramIcon.vue'
export { default as IconTime } from '../..\\components\\icon\\Time.vue'
export { default as IconTreeIcon } from '../..\\components\\icon\\TreeIcon.vue'
export { default as IconTvIcon } from '../..\\components\\icon\\TvIcon.vue'
export { default as IconWp } from '../..\\components\\icon\\Wp.vue'
export { default as TagsAvailbleTag } from '../..\\components\\tags\\AvailbleTag.vue'
export { default as TagsHotTag } from '../..\\components\\tags\\HotTag.vue'
export { default as TagsLocationTag } from '../..\\components\\tags\\LocationTag.vue'
export { default as StatisticsCardVertical } from '../..\\components\\statistics-card\\StatisticsCardVertical.vue'
export { default as TypographyHeadlines } from '../..\\components\\typography\\TypographyHeadlines.vue'
export { default as TypographyTexts } from '../..\\components\\typography\\TypographyTexts.vue'
export { default as VerticalNavMenu } from '../..\\components\\vertical-nav-menu\\VerticalNavMenu.vue'
export { default as FormLayoutsDemosDemoFormLayoutHorizontal } from '../..\\components\\form-layouts\\demos\\DemoFormLayoutHorizontal.vue'
export { default as FormLayoutsDemosDemoFormLayoutHorizontalIcon } from '../..\\components\\form-layouts\\demos\\DemoFormLayoutHorizontalIcon.vue'
export { default as FormLayoutsDemosDemoFormLayoutMultipleColumn } from '../..\\components\\form-layouts\\demos\\DemoFormLayoutMultipleColumn.vue'
export { default as FormLayoutsDemosDemoFormLayoutVerticalForm } from '../..\\components\\form-layouts\\demos\\DemoFormLayoutVerticalForm.vue'
export { default as FormLayoutsDemosDemoFormLayoutVerticalFormWithIcons } from '../..\\components\\form-layouts\\demos\\DemoFormLayoutVerticalFormWithIcons.vue'
export { default as SimpleTableDemosDemoSimpleTableBasic } from '../..\\components\\simple-table\\demos\\DemoSimpleTableBasic.vue'
export { default as SimpleTableDemosDemoSimpleTableDark } from '../..\\components\\simple-table\\demos\\DemoSimpleTableDark.vue'
export { default as SimpleTableDemosDemoSimpleTableDense } from '../..\\components\\simple-table\\demos\\DemoSimpleTableDense.vue'
export { default as SimpleTableDemosDemoSimpleTableFixedHeader } from '../..\\components\\simple-table\\demos\\DemoSimpleTableFixedHeader.vue'
export { default as SimpleTableDemosDemoSimpleTableHeight } from '../..\\components\\simple-table\\demos\\DemoSimpleTableHeight.vue'
export { default as VerticalNavMenuGroup } from '../..\\components\\vertical-nav-menu\\components\\NavMenuGroup.vue'
export { default as VerticalNavMenuLink } from '../..\\components\\vertical-nav-menu\\components\\NavMenuLink.vue'
export { default as VerticalNavMenuSectionTitle } from '../..\\components\\vertical-nav-menu\\components\\NavMenuSectionTitle.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
