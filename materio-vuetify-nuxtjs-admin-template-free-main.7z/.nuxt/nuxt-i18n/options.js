

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
}
export const nuxtOptions = {
  isUniversalMode: false,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {"fallbackLocale":"en","messages":{"en":{"aboutHouse":"About the house","price":"Price","pricePeriod":"Find out the price for the period","contact":"Contacts","houses":"Houses","aboutUs":"About Us","advantages":"Advantages","month":"Month","monthsX2":"Two Months","monthsX3":"Three Months","hiddenPrice":"Show hidden price (that price only for rent > 1 month)","tv":"TV","garden":"Garden","bathroom":"Bathroom","bathrooms":"{count} Bathroom | {count} Bathrooms","search":"Search","filters":"Filters","searchLabel":"Find what you're looking for","dates":"Dates","rooms":"{count} Room | {count} Rooms","tabs":"Tabs","pricePerMonth":"Price per month","hot":"Hot","willBeAvailable":"Will be available:","perMonth":"per Month","cleaning":"Cleaning","fridge":"Fridge","parking":"Parking","available":"Available now","ac":"AC","released":"Will be released","kitchen":"Kitchen","distanceBeach":"Distance to the beach"},"ru":{"aboutHouse":"Информация о доме","price":"Цена","pricePeriod":"Узнать цену за период","contact":"Контакты","houses":"Дома","aboutUs":"О нас","advantages":"Преимущества","month":"Месяц","monthsX2":"Два месяца","monthsX3":"Три месяца","hiddenPrice":"Показать скрытую цену (такая цена только при аренде > 1 месяца)","tv":"Телевизор","garden":"Сад","bathroom":"Ванная","bathrooms":"{count} Ванная | {count} Ванные","search":"Поиск","filters":"Фильтры","searchLabel":"Найдите то, что ищете","dates":"Даты","rooms":"{count} Комната | {count} Комнаты","parking":"Парковка","tabs":"Табы","pricePerMonth":"Цена в месяц","hot":"Популярное","available":"Доступно","willBeAvailable":"Будет доступно:","perMonth":"в месяц","cleaning":"Уборка","fridge":"Холодильник","ac":"Кондиционеры","released":"Освободится","kitchen":"Кухня","distanceBeach":"Дистанция до пляжа"}}},
  vueI18nLoader: false,
  locales: [{"code":"en","name":"English"},{"code":"ru","name":"Русский"}],
  defaultLocale: "en",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix_except_default",
  lazy: false,
  langDir: null,
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"i18n_redirected","cookieSecure":false,"fallbackLocale":"","onlyOnNoPrefix":false,"onlyOnRoot":false,"useCookie":true},
  differentDomains: false,
  seo: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncLocale":false,"syncMessages":false,"syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  beforeLanguageSwitch: () => null,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"en","name":"English"},{"code":"ru","name":"Русский"}],
  localeCodes: ["en","ru"],
}

export const localeMessages = {}
