import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _34a5f706 = () => interopDefault(import('..\\pages\\account-settings.vue' /* webpackChunkName: "pages/account-settings" */))
const _16eb1c4a = () => interopDefault(import('..\\pages\\card.vue' /* webpackChunkName: "pages/card" */))
const _f038a7f0 = () => interopDefault(import('..\\pages\\createHouse\\index.vue' /* webpackChunkName: "pages/createHouse/index" */))
const _1f48048c = () => interopDefault(import('..\\pages\\form-layouts.vue' /* webpackChunkName: "pages/form-layouts" */))
const _2fdfc755 = () => interopDefault(import('..\\pages\\houses\\index.vue' /* webpackChunkName: "pages/houses/index" */))
const _95598a60 = () => interopDefault(import('..\\pages\\housesAdmin\\index.vue' /* webpackChunkName: "pages/housesAdmin/index" */))
const _f4427360 = () => interopDefault(import('..\\pages\\icons.vue' /* webpackChunkName: "pages/icons" */))
const _7139a31f = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _042c1141 = () => interopDefault(import('..\\pages\\mapPage.vue' /* webpackChunkName: "pages/mapPage" */))
const _3ec2a546 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _b0dbfff0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _5036a9ad = () => interopDefault(import('..\\pages\\simple-table.vue' /* webpackChunkName: "pages/simple-table" */))
const _e05cd5b0 = () => interopDefault(import('..\\pages\\testD.vue' /* webpackChunkName: "pages/testD" */))
const _19f3ed69 = () => interopDefault(import('..\\pages\\typography.vue' /* webpackChunkName: "pages/typography" */))
const _1b50b75d = () => interopDefault(import('..\\pages\\houses\\card.vue' /* webpackChunkName: "pages/houses/card" */))
const _58d7da6f = () => interopDefault(import('..\\pages\\houses\\HouseColendar.vue' /* webpackChunkName: "pages/houses/HouseColendar" */))
const _d46bb584 = () => interopDefault(import('..\\pages\\houses\\HouseExpenses.vue' /* webpackChunkName: "pages/houses/HouseExpenses" */))
const _237734db = () => interopDefault(import('..\\pages\\houses\\HouseImages.vue' /* webpackChunkName: "pages/houses/HouseImages" */))
const _464efa5e = () => interopDefault(import('..\\pages\\houses\\HouseInfo.vue' /* webpackChunkName: "pages/houses/HouseInfo" */))
const _72336882 = () => interopDefault(import('..\\pages\\housesAdmin\\card.vue' /* webpackChunkName: "pages/housesAdmin/card" */))
const _93ecba2c = () => interopDefault(import('..\\pages\\housesAdmin\\HouseColendar.vue' /* webpackChunkName: "pages/housesAdmin/HouseColendar" */))
const _1a08248e = () => interopDefault(import('..\\pages\\housesAdmin\\HouseExpenses.vue' /* webpackChunkName: "pages/housesAdmin/HouseExpenses" */))
const _5de6e016 = () => interopDefault(import('..\\pages\\housesAdmin\\HouseImages.vue' /* webpackChunkName: "pages/housesAdmin/HouseImages" */))
const _67c07e68 = () => interopDefault(import('..\\pages\\housesAdmin\\HouseInfo.vue' /* webpackChunkName: "pages/housesAdmin/HouseInfo" */))
const _941cca06 = () => interopDefault(import('..\\pages\\houses\\_id.vue' /* webpackChunkName: "pages/houses/_id" */))
const _0311b138 = () => interopDefault(import('..\\pages\\housesAdmin\\_id.vue' /* webpackChunkName: "pages/housesAdmin/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/account-settings",
    component: _34a5f706,
    name: "account-settings___en"
  }, {
    path: "/card",
    component: _16eb1c4a,
    name: "card___en"
  }, {
    path: "/createHouse",
    component: _f038a7f0,
    name: "createHouse___en"
  }, {
    path: "/form-layouts",
    component: _1f48048c,
    name: "form-layouts___en"
  }, {
    path: "/houses",
    component: _2fdfc755,
    name: "houses___en"
  }, {
    path: "/housesAdmin",
    component: _95598a60,
    name: "housesAdmin___en"
  }, {
    path: "/icons",
    component: _f4427360,
    name: "icons___en"
  }, {
    path: "/login",
    component: _7139a31f,
    name: "login___en"
  }, {
    path: "/mapPage",
    component: _042c1141,
    name: "mapPage___en"
  }, {
    path: "/register",
    component: _3ec2a546,
    name: "register___en"
  }, {
    path: "/ru",
    component: _b0dbfff0,
    name: "index___ru"
  }, {
    path: "/simple-table",
    component: _5036a9ad,
    name: "simple-table___en"
  }, {
    path: "/testD",
    component: _e05cd5b0,
    name: "testD___en"
  }, {
    path: "/typography",
    component: _19f3ed69,
    name: "typography___en"
  }, {
    path: "/houses/card",
    component: _1b50b75d,
    name: "houses-card___en"
  }, {
    path: "/houses/HouseColendar",
    component: _58d7da6f,
    name: "houses-HouseColendar___en"
  }, {
    path: "/houses/HouseExpenses",
    component: _d46bb584,
    name: "houses-HouseExpenses___en"
  }, {
    path: "/houses/HouseImages",
    component: _237734db,
    name: "houses-HouseImages___en"
  }, {
    path: "/houses/HouseInfo",
    component: _464efa5e,
    name: "houses-HouseInfo___en"
  }, {
    path: "/housesAdmin/card",
    component: _72336882,
    name: "housesAdmin-card___en"
  }, {
    path: "/housesAdmin/HouseColendar",
    component: _93ecba2c,
    name: "housesAdmin-HouseColendar___en"
  }, {
    path: "/housesAdmin/HouseExpenses",
    component: _1a08248e,
    name: "housesAdmin-HouseExpenses___en"
  }, {
    path: "/housesAdmin/HouseImages",
    component: _5de6e016,
    name: "housesAdmin-HouseImages___en"
  }, {
    path: "/housesAdmin/HouseInfo",
    component: _67c07e68,
    name: "housesAdmin-HouseInfo___en"
  }, {
    path: "/ru/account-settings",
    component: _34a5f706,
    name: "account-settings___ru"
  }, {
    path: "/ru/card",
    component: _16eb1c4a,
    name: "card___ru"
  }, {
    path: "/ru/createHouse",
    component: _f038a7f0,
    name: "createHouse___ru"
  }, {
    path: "/ru/form-layouts",
    component: _1f48048c,
    name: "form-layouts___ru"
  }, {
    path: "/ru/houses",
    component: _2fdfc755,
    name: "houses___ru"
  }, {
    path: "/ru/housesAdmin",
    component: _95598a60,
    name: "housesAdmin___ru"
  }, {
    path: "/ru/icons",
    component: _f4427360,
    name: "icons___ru"
  }, {
    path: "/ru/login",
    component: _7139a31f,
    name: "login___ru"
  }, {
    path: "/ru/mapPage",
    component: _042c1141,
    name: "mapPage___ru"
  }, {
    path: "/ru/register",
    component: _3ec2a546,
    name: "register___ru"
  }, {
    path: "/ru/simple-table",
    component: _5036a9ad,
    name: "simple-table___ru"
  }, {
    path: "/ru/testD",
    component: _e05cd5b0,
    name: "testD___ru"
  }, {
    path: "/ru/typography",
    component: _19f3ed69,
    name: "typography___ru"
  }, {
    path: "/ru/houses/card",
    component: _1b50b75d,
    name: "houses-card___ru"
  }, {
    path: "/ru/houses/HouseColendar",
    component: _58d7da6f,
    name: "houses-HouseColendar___ru"
  }, {
    path: "/ru/houses/HouseExpenses",
    component: _d46bb584,
    name: "houses-HouseExpenses___ru"
  }, {
    path: "/ru/houses/HouseImages",
    component: _237734db,
    name: "houses-HouseImages___ru"
  }, {
    path: "/ru/houses/HouseInfo",
    component: _464efa5e,
    name: "houses-HouseInfo___ru"
  }, {
    path: "/ru/housesAdmin/card",
    component: _72336882,
    name: "housesAdmin-card___ru"
  }, {
    path: "/ru/housesAdmin/HouseColendar",
    component: _93ecba2c,
    name: "housesAdmin-HouseColendar___ru"
  }, {
    path: "/ru/housesAdmin/HouseExpenses",
    component: _1a08248e,
    name: "housesAdmin-HouseExpenses___ru"
  }, {
    path: "/ru/housesAdmin/HouseImages",
    component: _5de6e016,
    name: "housesAdmin-HouseImages___ru"
  }, {
    path: "/ru/housesAdmin/HouseInfo",
    component: _67c07e68,
    name: "housesAdmin-HouseInfo___ru"
  }, {
    path: "/ru/houses/:id",
    component: _941cca06,
    name: "houses-id___ru"
  }, {
    path: "/ru/housesAdmin/:id",
    component: _0311b138,
    name: "housesAdmin-id___ru"
  }, {
    path: "/houses/:id",
    component: _941cca06,
    name: "houses-id___en"
  }, {
    path: "/housesAdmin/:id",
    component: _0311b138,
    name: "housesAdmin-id___en"
  }, {
    path: "/",
    component: _b0dbfff0,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
