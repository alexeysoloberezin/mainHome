<template>
  <div>
    <!--    https://www.zeemaps.com/ -->
    <!--    alex..gmail 06..q-->
    <iframe frameborder=0 style='width:100%;height:calc(100vh - 100px)' src='//www.zeemaps.com/pub?group=4664037&locate=1&shuttered=1&add=1'> </iframe>
  </div>
</template>

<script>
export default {
  name: 'MapPage'
}
</script>

<style scoped>

</style>
