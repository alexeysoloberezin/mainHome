<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="23.078" height="23.078" viewBox="0 0 23.078 23.078">
    <path id="Path_22630" data-name="Path 22630" d="M19.7,14.918a11.5,11.5,0,0,0-4.385-2.75,6.671,6.671,0,1,0-7.549,0A11.557,11.557,0,0,0,0,23.078H1.8a9.736,9.736,0,1,1,19.472,0h1.8A11.464,11.464,0,0,0,19.7,14.918Zm-8.159-3.38a4.868,4.868,0,1,1,4.868-4.868A4.873,4.873,0,0,1,11.539,11.539Z" fill="#282828"/>
  </svg>
</template>

<script>
export default {
  name: "GuestIcon"
}
</script>

<style scoped>

</style>
