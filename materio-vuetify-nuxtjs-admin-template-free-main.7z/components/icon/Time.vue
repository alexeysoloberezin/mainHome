<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="21.979" height="22.001" viewBox="0 0 21.979 22.001">
    <g id="Group_13112" data-name="Group 13112" transform="translate(-499 -1241.999)">
      <path id="Path_22730" data-name="Path 22730" d="M22,11a1,1,0,0,0-1,1,9.018,9.018,0,1,1-3.355-7H16a1,1,0,0,0,0,2h4a1,1,0,0,0,1-1V2a1,1,0,0,0-2,0V3.531A10.989,10.989,0,1,0,23,12a1,1,0,0,0-1-1Z" transform="translate(497.979 1240.999)" fill="#282828"/>
      <path id="Path_22731" data-name="Path 22731" d="M12,5a1,1,0,0,0-1,1v6a1,1,0,0,0,.293.707l3,3a1,1,0,1,0,1.414-1.414L13,11.586V6a1,1,0,0,0-1-1Z" transform="translate(497.979 1240.999)" fill="#282828"/>
    </g>
  </svg>
</template>

<script>
export default {
  name: "TimeIcon"
}
</script>

<style scoped>

</style>
